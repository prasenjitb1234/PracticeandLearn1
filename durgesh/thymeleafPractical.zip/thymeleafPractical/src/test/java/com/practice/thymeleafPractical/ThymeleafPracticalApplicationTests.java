package com.practice.thymeleafPractical;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeleafPracticalApplicationTests {

	@Test
	void contextLoads() {
	}

}
