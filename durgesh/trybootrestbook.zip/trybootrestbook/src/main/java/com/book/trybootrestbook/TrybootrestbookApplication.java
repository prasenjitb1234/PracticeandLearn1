package com.book.trybootrestbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrybootrestbookApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrybootrestbookApplication.class, args);
	}

}
